
import { useEffect, useState } from 'react';
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Award, BookOpen, FileText, Medal, Star, TrendingUp } from "lucide-react";

interface Achievement {
  id: number;
  type: string;
  title: string;
  date: string;
  score: number;
  status: 'pending' | 'approved' | 'rejected';
}

const Profile = () => {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [totalScore, setTotalScore] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching user achievements from an API
    setTimeout(() => {
      const mockAchievements: Achievement[] = [
        {
          id: 1,
          type: 'patent',
          title: 'AI-Based Learning Algorithm',
          date: '2025-03-15',
          score: 30,
          status: 'approved'
        },
        {
          id: 2,
          type: 'research',
          title: 'Machine Learning in Education',
          date: '2025-02-10',
          score: 25,
          status: 'approved'
        },
        {
          id: 3,
          type: 'award',
          title: 'Young Innovator Award',
          date: '2025-01-05',
          score: 15,
          status: 'approved'
        },
        {
          id: 4,
          type: 'startup',
          title: 'EdTech Solutions Platform',
          date: '2025-03-28',
          score: 40,
          status: 'pending'
        }
      ];
      
      setAchievements(mockAchievements);
      const approvedAchievements = mockAchievements.filter(a => a.status === 'approved');
      setTotalScore(approvedAchievements.reduce((total, achievement) => total + achievement.score, 0));
      setLoading(false);
    }, 500);
  }, []);

  const getAchievementIcon = (type: string) => {
    switch (type) {
      case 'patent':
        return <FileText className="h-5 w-5 text-innovation-blue" />;
      case 'research':
        return <BookOpen className="h-5 w-5 text-innovation-purple" />;
      case 'award':
        return <Award className="h-5 w-5 text-innovation-teal" />;
      case 'startup':
        return <TrendingUp className="h-5 w-5 text-innovation-blue" />;
      default:
        return <Star className="h-5 w-5 text-yellow-500" />;
    }
  };

  const getStatusBadge = (status: 'pending' | 'approved' | 'rejected') => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-500">Approved</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-500">Pending</Badge>;
      case 'rejected':
        return <Badge className="bg-red-500">Rejected</Badge>;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-10">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-6">My Profile</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Innovation Score</CardTitle>
                  <CardDescription>Your contribution to innovation excellence</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="relative w-36 h-36 mx-auto mb-4">
                      <div className="absolute inset-0 rounded-full bg-innovation-blue/10 flex items-center justify-center">
                        <Medal className="h-16 w-16 text-innovation-blue" />
                      </div>
                      <svg className="w-full h-full" viewBox="0 0 100 100">
                        <circle 
                          className="text-gray-200" 
                          strokeWidth="10" 
                          stroke="currentColor" 
                          fill="transparent" 
                          r="40" 
                          cx="50" 
                          cy="50" 
                        />
                        <circle 
                          className="text-innovation-blue" 
                          strokeWidth="10" 
                          strokeDasharray={Math.min(totalScore / 100 * 251, 251)} 
                          strokeDashoffset="0" 
                          strokeLinecap="round" 
                          stroke="currentColor" 
                          fill="transparent" 
                          r="40" 
                          cx="50" 
                          cy="50" 
                        />
                      </svg>
                    </div>
                    
                    <div className="text-4xl font-bold mb-2">{totalScore}</div>
                    <p className="text-sm text-gray-500">Total Innovation Points</p>
                    
                    <div className="mt-6">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Progress to Next Level</span>
                        <span>{totalScore}/100</span>
                      </div>
                      <Progress value={totalScore} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>My Achievements</CardTitle>
                  <CardDescription>Your innovation contributions and their status</CardDescription>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex justify-center items-center h-40">
                      <p>Loading achievements...</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {achievements.map((achievement) => (
                        <div key={achievement.id} className="flex items-center p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                          <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mr-4">
                            {getAchievementIcon(achievement.type)}
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <h3 className="font-medium">{achievement.title}</h3>
                              <div className="flex items-center space-x-2">
                                <span className="text-sm font-medium text-gray-600">+{achievement.score} pts</span>
                                {getStatusBadge(achievement.status)}
                              </div>
                            </div>
                            <div className="flex justify-between text-sm text-gray-500 mt-1">
                              <span className="capitalize">{achievement.type}</span>
                              <span>{achievement.date}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Profile;
