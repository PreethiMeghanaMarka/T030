
import { Button } from '@/components/ui/button';
import { ChevronRight } from 'lucide-react';

const CtaSection = () => {
  return (
    <section className="py-20 bg-gray-900 text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Transform Your Institution's Innovation Landscape?
          </h2>
          <p className="text-lg text-gray-300 mb-8">
            Join the community of forward-thinking educational institutions leveraging data-driven insights to foster a culture of innovation excellence.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" className="bg-innovation-blue hover:bg-innovation-blue/90">
              Get Started Today
              <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white/20 hover:bg-white/10">
              Request Demo
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;
