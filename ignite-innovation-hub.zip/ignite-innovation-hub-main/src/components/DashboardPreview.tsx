
import { useEffect, useState } from 'react';
import { 
  BarChart3, 
  PieChart, 
  LineChart, 
  Users, 
  BookOpen, 
  FileText, 
  Award, 
  ShieldCheck 
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsBarChart,
  Pie,
  Cell
} from 'recharts';

const DashboardPreview = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const [barChartData, setBarChartData] = useState<Array<{name: string, value: number}>>([]);
  
  useEffect(() => {
    // Use actual data for the bar chart
    setBarChartData([
      { name: 'Engineering', value: 65 },
      { name: 'Sciences', value: 40 },
      { name: 'Business', value: 85 },
      { name: 'Arts', value: 30 },
      { name: 'Medicine', value: 55 },
      { name: 'Education', value: 75 }
    ]);
  }, [activeTab]);

  const pieData = [
    { name: 'Patents', value: 35, color: '#3A57E8' },
    { name: 'Research', value: 45, color: '#8E44AD' },
    { name: 'Projects', value: 20, color: '#20C997' }
  ];
  
  const stats = [
    { icon: <FileText className="h-5 w-5 text-innovation-blue" />, label: "Publications", value: "142" },
    { icon: <Award className="h-5 w-5 text-innovation-purple" />, label: "Patents", value: "37" },
    { icon: <Users className="h-5 w-5 text-innovation-teal" />, label: "Contributors", value: "214" },
    { icon: <BookOpen className="h-5 w-5 text-innovation-lightBlue" />, label: "Projects", value: "89" }
  ];
  
  return (
    <section id="dashboard" className="section-padding">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="mb-4">Interactive <span className="gradient-text">Dashboard</span></h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Gain valuable insights through our intuitive dashboard that transforms complex innovation data into clear, actionable information.
          </p>
        </div>
        
        <div className="bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden">
          <div className="border-b border-gray-100">
            <div className="flex justify-between items-center p-6">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="h-6 w-6 text-innovation-blue" />
                <h3 className="text-xl font-medium">Innovation Excellence Dashboard</h3>
              </div>
              <div className="hidden md:block">
                <Button variant="outline" size="sm" className="mr-2">Export Data</Button>
                <Button size="sm">Add New Entry</Button>
              </div>
            </div>
          </div>
          
          <Tabs defaultValue="overview" className="p-6" onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="publications">Publications</TabsTrigger>
              <TabsTrigger value="patents">Patents</TabsTrigger>
              <TabsTrigger value="projects">Projects</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {stats.map((stat, index) => (
                  <Card key={index} className="stat-card">
                    <div className="w-12 h-12 rounded-full bg-gray-50 flex items-center justify-center mb-3">
                      {stat.icon}
                    </div>
                    <div className="text-3xl font-bold mb-1">{stat.value}</div>
                    <div className="text-gray-500">{stat.label}</div>
                  </Card>
                ))}
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="col-span-2">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center mb-6">
                      <h4 className="font-medium">Innovation by Department</h4>
                      <BarChart3 className="h-5 w-5 text-gray-400" />
                    </div>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={barChartData}
                          margin={{
                            top: 5,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="value" fill="#3A57E8" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center mb-6">
                      <h4 className="font-medium">Innovation Types</h4>
                      <PieChart className="h-5 w-5 text-gray-400" />
                    </div>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsBarChart>
                          <Pie
                            data={pieData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {pieData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </RechartsBarChart>
                      </ResponsiveContainer>
                      <div className="flex justify-around text-xs text-gray-500 mt-4">
                        {pieData.map((entry, index) => (
                          <div key={index} className="flex items-center">
                            <div 
                              className="w-3 h-3 rounded-full mr-1" 
                              style={{ backgroundColor: entry.color }}
                            ></div>
                            <span>{entry.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="publications">
              <div className="h-80 flex items-center justify-center">
                <div className="text-center p-8">
                  <LineChart className="h-16 w-16 mx-auto mb-4 text-innovation-blue opacity-30" />
                  <h4 className="text-xl font-medium mb-2">Publication Analytics</h4>
                  <p className="text-gray-500 max-w-md">
                    Track publication metrics including journal impact factors, citation counts, and departmental contributions.
                  </p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="patents">
              <div className="h-80 flex items-center justify-center">
                <div className="text-center p-8">
                  <Award className="h-16 w-16 mx-auto mb-4 text-innovation-purple opacity-30" />
                  <h4 className="text-xl font-medium mb-2">Patent Analytics</h4>
                  <p className="text-gray-500 max-w-md">
                    Monitor patent applications, grants, commercial potential, and innovation trends.
                  </p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="projects">
              <div className="h-80 flex items-center justify-center">
                <div className="text-center p-8">
                  <BookOpen className="h-16 w-16 mx-auto mb-4 text-innovation-teal opacity-30" />
                  <h4 className="text-xl font-medium mb-2">Project Analytics</h4>
                  <p className="text-gray-500 max-w-md">
                    Track research projects, funding sources, team compositions, and collaboration metrics.
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </section>
  );
};

export default DashboardPreview;
