
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { LineChart, BarChart, Smartphone, Laptop, AreaChart, PieChart, ActivitySquare, BarChart3 } from 'lucide-react';

const AnalyticsSection = () => {
  return (
    <section id="analytics" className="section-padding bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="mb-4">Actionable <span className="gradient-text">Analytics</span></h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Transform raw data into meaningful insights with advanced analytics tools designed to drive innovation strategy.
          </p>
        </div>
        
        <div className="bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden mb-16">
          <Tabs defaultValue="trends">
            <div className="border-b border-gray-100">
              <div className="p-6">
                <TabsList>
                  <TabsTrigger value="trends">Trends Analysis</TabsTrigger>
                  <TabsTrigger value="impact">Impact Assessment</TabsTrigger>
                  <TabsTrigger value="reports">Reports</TabsTrigger>
                </TabsList>
              </div>
            </div>
            
            <TabsContent value="trends" className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <div className="lg:col-span-3">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-center mb-6">
                        <div>
                          <h4 className="font-medium text-lg">Innovation Growth Trends</h4>
                          <p className="text-gray-500 text-sm">5-year innovation activity analysis</p>
                        </div>
                        <LineChart className="h-5 w-5 text-gray-400" />
                      </div>
                      
                      <div className="h-64 relative">
                        {/* Line chart visualization */}
                        <div className="absolute bottom-0 left-0 w-full h-px bg-gray-200"></div>
                        <div className="absolute top-0 left-0 h-full w-px bg-gray-200"></div>
                        
                        <div className="relative h-full w-full">
                          <svg className="w-full h-full" viewBox="0 0 300 100" preserveAspectRatio="none">
                            <path 
                              d="M0,80 Q50,70 100,50 T200,40 T300,10" 
                              fill="none" 
                              stroke="url(#blue-gradient)" 
                              strokeWidth="3"
                            />
                            <defs>
                              <linearGradient id="blue-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" stopColor="rgba(58, 87, 232, 0.8)" />
                                <stop offset="100%" stopColor="rgba(142, 68, 173, 0.8)" />
                              </linearGradient>
                            </defs>
                          </svg>
                          
                          {/* Dots on the line */}
                          <div className="absolute bottom-[calc(20%_-_4px)] left-0 w-2 h-2 rounded-full bg-innovation-blue"></div>
                          <div className="absolute bottom-[calc(30%_-_4px)] left-[calc(33.33%_-_4px)] w-2 h-2 rounded-full bg-innovation-purple"></div>
                          <div className="absolute bottom-[calc(50%_-_4px)] left-[calc(66.67%_-_4px)] w-2 h-2 rounded-full bg-innovation-blue"></div>
                          <div className="absolute bottom-[calc(90%_-_4px)] right-0 w-2 h-2 rounded-full bg-innovation-purple"></div>
                        </div>
                        
                        {/* X-axis labels */}
                        <div className="absolute bottom-[-25px] left-0 w-full flex justify-between text-xs text-gray-500">
                          <div>2020</div>
                          <div>2021</div>
                          <div>2022</div>
                          <div>2023</div>
                          <div>2024</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                <div>
                  <div className="space-y-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-start">
                          <div className="w-10 h-10 rounded bg-innovation-blue/10 flex items-center justify-center mr-3">
                            <ActivitySquare className="h-5 w-5 text-innovation-blue" />
                          </div>
                          <div>
                            <div className="text-sm text-gray-500">Growth Rate</div>
                            <div className="text-2xl font-semibold">+27%</div>
                            <div className="text-xs text-green-600">+7% from last year</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-start">
                          <div className="w-10 h-10 rounded bg-innovation-purple/10 flex items-center justify-center mr-3">
                            <BarChart3 className="h-5 w-5 text-innovation-purple" />
                          </div>
                          <div>
                            <div className="text-sm text-gray-500">Total Innovations</div>
                            <div className="text-2xl font-semibold">548</div>
                            <div className="text-xs text-green-600">+124 from last year</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-start">
                          <div className="w-10 h-10 rounded bg-innovation-teal/10 flex items-center justify-center mr-3">
                            <PieChart className="h-5 w-5 text-innovation-teal" />
                          </div>
                          <div>
                            <div className="text-sm text-gray-500">Dept. Participation</div>
                            <div className="text-2xl font-semibold">92%</div>
                            <div className="text-xs text-green-600">+15% from last year</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="impact" className="p-6">
              <div className="h-64 flex items-center justify-center">
                <div className="text-center p-8">
                  <AreaChart className="h-16 w-16 mx-auto mb-4 text-innovation-purple opacity-30" />
                  <h4 className="text-xl font-medium mb-2">Impact Visualization</h4>
                  <p className="text-gray-500 max-w-md">
                    Measure and visualize the real-world impact of your institution's innovation activities.
                  </p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="reports" className="p-6">
              <div className="h-64 flex items-center justify-center">
                <div className="text-center p-8">
                  <BarChart className="h-16 w-16 mx-auto mb-4 text-innovation-blue opacity-30" />
                  <h4 className="text-xl font-medium mb-2">Custom Reports</h4>
                  <p className="text-gray-500 max-w-md">
                    Generate comprehensive reports with customizable parameters to meet your specific needs.
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="bg-gradient-to-r from-innovation-blue to-innovation-purple rounded-xl overflow-hidden shadow-xl">
          <div className="grid grid-cols-1 md:grid-cols-3">
            <div className="p-8 md:p-12 md:col-span-2 text-white">
              <h3 className="text-2xl md:text-3xl font-bold mb-4">Responsive Across All Devices</h3>
              <p className="mb-6 text-white/90">
                Access your innovation data anytime, anywhere with our fully responsive interface optimized for all devices.
              </p>
              <div className="flex space-x-4">
                <Button variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                  <Smartphone className="mr-2 h-4 w-4" />
                  Mobile View
                </Button>
                <Button variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                  <Laptop className="mr-2 h-4 w-4" />
                  Desktop View
                </Button>
              </div>
            </div>
            
            <div className="relative md:block hidden">
              <div className="absolute top-1/2 left-0 transform -translate-y-1/2 -translate-x-12">
                <div className="w-64 h-64 bg-white/10 rounded-full"></div>
              </div>
              <div className="absolute bottom-1/4 right-1/4">
                <div className="w-32 h-32 bg-white/5 rounded-full"></div>
              </div>
              <div className="absolute top-1/4 right-1/3">
                <div className="w-16 h-16 bg-white/10 rounded-full"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AnalyticsSection;
