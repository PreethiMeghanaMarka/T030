
import { Button } from '@/components/ui/button';
import { ChevronRight, FileSpreadsheet, BarChart2, Award } from 'lucide-react';

const HeroSection = () => {
  return (
    <section id="home" className="relative overflow-hidden bg-gradient-to-b from-white to-blue-50 section-padding">
      <div className="absolute inset-0 bg-hero-pattern opacity-50"></div>
      <div className="container mx-auto px-4 relative">
        <div className="flex flex-col lg:flex-row items-center">
          <div className="lg:w-1/2 mb-10 lg:mb-0">
            <h1 className="mb-6">
              <span className="gradient-text">Transform</span> Your Institution's
              <span className="gradient-text"> Innovation Landscape</span>
            </h1>
            <p className="text-lg text-gray-600 mb-8 max-w-lg">
              A comprehensive platform designed to track, visualize, and celebrate innovation excellence across your educational institution.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-innovation-blue hover:bg-innovation-blue/90 text-white">
                Get Started
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
              <Button variant="outline" className="border-innovation-purple text-innovation-purple hover:bg-innovation-purple/10">
                Explore Features
              </Button>
            </div>
            
            <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 rounded-full bg-innovation-blue/10 flex items-center justify-center">
                  <FileSpreadsheet className="h-5 w-5 text-innovation-blue" />
                </div>
                <div>
                  <p className="font-medium">Data Collection</p>
                  <p className="text-sm text-gray-500">Streamlined Process</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 rounded-full bg-innovation-purple/10 flex items-center justify-center">
                  <BarChart2 className="h-5 w-5 text-innovation-purple" />
                </div>
                <div>
                  <p className="font-medium">Visualizations</p>
                  <p className="text-sm text-gray-500">Clear Insights</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 rounded-full bg-innovation-teal/10 flex items-center justify-center">
                  <Award className="h-5 w-5 text-innovation-teal" />
                </div>
                <div>
                  <p className="font-medium">Recognition</p>
                  <p className="text-sm text-gray-500">Celebrate Excellence</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:w-1/2 relative">
            <div className="relative w-full h-[460px] rounded-lg overflow-hidden shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-br from-innovation-blue/20 to-innovation-purple/20 backdrop-blur-sm"></div>
              
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-full max-w-md mx-auto p-6 space-y-8">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold mb-2 gradient-text">Innovation Excellence</h3>
                    <p className="text-gray-600">Monitor, visualize, and celebrate achievements</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white/80 backdrop-blur-sm p-4 rounded-lg shadow-md">
                      <div className="h-4 w-24 bg-innovation-blue/20 rounded-full mb-2"></div>
                      <div className="h-24 bg-gradient-to-r from-innovation-blue/10 to-innovation-purple/10 rounded-md"></div>
                      <div className="mt-2 h-3 w-full bg-gray-200 rounded-full">
                        <div className="h-full w-[70%] bg-innovation-blue rounded-full"></div>
                      </div>
                    </div>
                    
                    <div className="bg-white/80 backdrop-blur-sm p-4 rounded-lg shadow-md">
                      <div className="h-4 w-20 bg-innovation-purple/20 rounded-full mb-2"></div>
                      <div className="grid grid-cols-4 gap-1 h-24">
                        {[40, 70, 55, 85].map((height, index) => (
                          <div key={index} className="flex items-end h-full">
                            <div 
                              className="w-full rounded-t-sm bg-innovation-purple/70"
                              style={{ 
                                height: `${height}%` 
                              }}
                            ></div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-2 h-3 w-full bg-gray-200 rounded-full">
                        <div className="h-full w-[60%] bg-innovation-purple rounded-full"></div>
                      </div>
                    </div>
                    
                    <div className="col-span-2 bg-white/80 backdrop-blur-sm p-4 rounded-lg shadow-md">
                      <div className="flex justify-between mb-3">
                        <div className="h-4 w-32 bg-innovation-teal/20 rounded-full"></div>
                        <div className="h-4 w-16 bg-gray-200 rounded-full"></div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="w-16 h-16 rounded-full bg-innovation-teal/20 flex items-center justify-center">
                          <Award className="h-8 w-8 text-innovation-teal" />
                        </div>
                        <div className="flex-1">
                          <div className="h-3 w-32 bg-gray-300 rounded-full mb-2"></div>
                          <div className="h-2 w-48 bg-gray-200 rounded-full mb-2"></div>
                          <div className="h-2 w-40 bg-gray-200 rounded-full"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-innovation-blue/10 rounded-full animate-pulse-subtle"></div>
              <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-56 h-56 bg-innovation-purple/10 rounded-full animate-pulse-subtle"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 border border-white/20 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
