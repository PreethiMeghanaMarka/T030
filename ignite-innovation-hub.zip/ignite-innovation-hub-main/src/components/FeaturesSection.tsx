
import { 
  Users, 
  FileInput, 
  LayoutDashboard, 
  BarChart2, 
  TrendingUp, 
  Award, 
  LineChart, 
  Smartphone 
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const features = [
  {
    icon: <Users className="h-8 w-8 text-white" />,
    title: "User Authentication",
    description: "Secure role-based access for administrators, faculty, and students with personalized dashboards.",
    bgColor: "bg-innovation-blue"
  },
  {
    icon: <FileInput className="h-8 w-8 text-white" />,
    title: "Innovation Data Entry",
    description: "Intuitive forms for submitting publications, patents, projects, and other innovation metrics.",
    bgColor: "bg-innovation-purple"
  },
  {
    icon: <LayoutDashboard className="h-8 w-8 text-white" />,
    title: "Dashboard",
    description: "Comprehensive overview of innovation metrics, recent submissions, and performance indicators.",
    bgColor: "bg-innovation-teal"
  },
  {
    icon: <BarChart2 className="h-8 w-8 text-white" />,
    title: "Data Visualization",
    description: "Interactive charts and graphs that transform complex data into actionable insights.",
    bgColor: "bg-innovation-lightBlue"
  },
  {
    icon: <TrendingUp className="h-8 w-8 text-white" />,
    title: "Innovation Indicators",
    description: "Track key performance indicators to measure growth and identify areas for improvement.",
    bgColor: "bg-innovation-lightPurple"
  },
  {
    icon: <Award className="h-8 w-8 text-white" />,
    title: "Recognition System",
    description: "Celebrate top innovators with badges, leaderboards, and customizable achievement systems.",
    bgColor: "bg-innovation-blue"
  },
  {
    icon: <LineChart className="h-8 w-8 text-white" />,
    title: "Analytics",
    description: "Advanced reporting tools for deeper insights and trend analysis over time.",
    bgColor: "bg-innovation-purple"
  },
  {
    icon: <Smartphone className="h-8 w-8 text-white" />,
    title: "Responsive UI",
    description: "Optimized experience across all devices, from desktop workstations to mobile phones.",
    bgColor: "bg-innovation-teal"
  }
];

const FeaturesSection = () => {
  return (
    <section id="features" className="section-padding bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="mb-4">Powerful <span className="gradient-text">Features</span></h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our Innovation Excellence Portal provides everything you need to track, analyze, and celebrate innovation across your educational institution.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border-none shadow-md card-hover overflow-hidden">
              <div className={`${feature.bgColor} p-4`}>
                <div className="w-14 h-14 rounded-lg bg-white/20 flex items-center justify-center">
                  {feature.icon}
                </div>
              </div>
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
