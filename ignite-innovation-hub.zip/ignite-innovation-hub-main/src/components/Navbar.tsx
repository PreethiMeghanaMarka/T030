
import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import {
  Menu,
  X,
  LayoutDashboard,
  FileInput,
  BarChart2,
  Award,
  BookOpen,
  LogIn,
  LogOut,
  User
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import AuthModal from '@/components/AuthModal';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    // Check authentication status on mount and when it changes
    const authStatus = localStorage.getItem('isAuthenticated') === 'true';
    setIsAuthenticated(authStatus);
  }, [location]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    setIsAuthenticated(false);
    
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out.",
    });
    
    if (location.pathname !== '/') {
      navigate('/');
    }
  };

  const handleLogin = () => {
    navigate('/login');
  };

  const navItems = [
    { name: 'Home', href: '/' },
    { name: 'Features', href: '/#features' },
    { name: 'Dashboard', href: '/#dashboard' },
    { name: 'Recognition', href: '/#recognition' },
    { name: 'Analytics', href: '/#analytics' },
    { name: 'Data Entry', href: '/data-entry', requiresAuth: true }
  ];

  // Filter nav items based on authentication status
  const filteredNavItems = navItems.filter(item => 
    !item.requiresAuth || (item.requiresAuth && isAuthenticated)
  );

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md shadow-sm">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Link to="/" className="flex items-center space-x-2">
              <BookOpen className="h-6 w-6 text-innovation-blue" />
              <span className="font-bold text-xl text-gray-800">Ignite<span className="text-innovation-purple">Innovation</span>Hub</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-8">
            {filteredNavItems.map((item) => (
              <Link 
                key={item.name}
                to={item.href}
                className={`text-gray-600 hover:text-innovation-blue transition-colors duration-200 ${
                  (location.pathname === item.href || 
                   (location.pathname === '/' && item.href.startsWith('/#')) ||
                   (item.href === '/data-entry' && location.pathname === '/data-entry')) 
                   ? 'text-innovation-blue font-medium' : ''
                }`}
              >
                {item.name}
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <Button variant="outline" className="border-innovation-purple text-innovation-purple hover:bg-innovation-purple/10"
                  onClick={() => navigate('/profile')}>
                  <User className="mr-2 h-4 w-4" />
                  My Profile
                </Button>
                <Button 
                  onClick={handleLogout} 
                  variant="outline" 
                  className="border-innovation-blue text-innovation-blue hover:bg-innovation-blue/10"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Log Out
                </Button>
              </div>
            ) : (
              <>
                <Button 
                  onClick={handleLogin} 
                  variant="outline" 
                  className="border-innovation-blue text-innovation-blue hover:bg-innovation-blue/10"
                >
                  <LogIn className="mr-2 h-4 w-4" />
                  Sign In
                </Button>
                <AuthModal>
                  <Button className="bg-innovation-blue hover:bg-innovation-blue/90">
                    Register
                  </Button>
                </AuthModal>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className="text-gray-700 hover:text-innovation-blue focus:outline-none"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute w-full">
          <div className="px-4 py-2 space-y-3">
            {filteredNavItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`block py-2 text-gray-600 hover:text-innovation-blue ${
                  (location.pathname === item.href || 
                  (location.pathname === '/' && item.href.startsWith('/#')) ||
                  (item.href === '/data-entry' && location.pathname === '/data-entry'))
                  ? 'text-innovation-blue font-medium' : ''
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
            <div className="pt-2 pb-4 space-y-2">
              {isAuthenticated ? (
                <>
                  <Button 
                    variant="outline" 
                    className="w-full border-innovation-purple text-innovation-purple"
                    onClick={() => {
                      navigate('/profile');
                      setIsMenuOpen(false);
                    }}
                  >
                    <User className="mr-2 h-4 w-4" />
                    My Profile
                  </Button>
                  <Button 
                    className="w-full bg-innovation-blue hover:bg-innovation-blue/90"
                    onClick={() => {
                      handleLogout();
                      setIsMenuOpen(false);
                    }}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    Log Out
                  </Button>
                </>
              ) : (
                <>
                  <Button 
                    variant="outline" 
                    className="w-full border-innovation-blue text-innovation-blue"
                    onClick={() => {
                      handleLogin();
                      setIsMenuOpen(false);
                    }}
                  >
                    <LogIn className="mr-2 h-4 w-4" />
                    Sign In
                  </Button>
                  <AuthModal>
                    <Button 
                      className="w-full bg-innovation-blue hover:bg-innovation-blue/90"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Register
                    </Button>
                  </AuthModal>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
