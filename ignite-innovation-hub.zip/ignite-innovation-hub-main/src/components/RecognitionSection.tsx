
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Star, Medal, Award, Crown, ThumbsUp } from 'lucide-react';

const topInnovators = [
  { 
    name: "Dr. Sarah Mitchell", 
    department: "Computer Science", 
    score: 96,
    achievements: ["Gold Innovator", "10+ Publications", "Patent Leader"],
    image: null,
    initials: "SM"
  },
  { 
    name: "Prof. James Wilson", 
    department: "Engineering", 
    score: 87,
    achievements: ["Silver Innovator", "Research Grant"],
    image: null,
    initials: "JW"
  },
  { 
    name: "Dr. Anita Patel", 
    department: "Medicine", 
    score: 82,
    achievements: ["Bronze Innovator", "Cross-Discipline Collaborator"],
    image: null,
    initials: "AP"
  },
  { 
    name: "Prof. David Lee", 
    department: "Physics", 
    score: 78,
    achievements: ["Rising Star", "New Patent"],
    image: null,
    initials: "DL"
  }
];

const departmentRanking = [
  { name: "Engineering", score: 341, change: "+12%" },
  { name: "Medicine", score: 287, change: "+8%" },
  { name: "Computer Science", score: 265, change: "+15%" },
  { name: "Business", score: 194, change: "+5%" }
];

const badges = [
  { 
    icon: <Trophy className="h-5 w-5 text-yellow-500" />, 
    name: "Gold Innovator", 
    description: "Awarded to top-tier innovators with exceptional contributions."
  },
  { 
    icon: <Star className="h-5 w-5 text-blue-500" />, 
    name: "Rising Star", 
    description: "Recognizes emerging talent and rapid growth in innovation metrics."
  },
  { 
    icon: <Medal className="h-5 w-5 text-green-500" />, 
    name: "Collaboration Champion", 
    description: "Celebrates those who excel at cross-department innovation efforts."
  },
  { 
    icon: <Award className="h-5 w-5 text-purple-500" />, 
    name: "Publication Excellence", 
    description: "Recognizes high-impact and frequently cited research publications."
  },
  { 
    icon: <Crown className="h-5 w-5 text-red-500" />, 
    name: "Patent Pioneer", 
    description: "Honors significant contributions to institutional patent portfolio."
  },
  { 
    icon: <ThumbsUp className="h-5 w-5 text-indigo-500" />, 
    name: "Mentor Merit", 
    description: "Acknowledges those who actively support others' innovation journeys."
  }
];

const RecognitionSection = () => {
  return (
    <section id="recognition" className="section-padding bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="mb-4">Recognition <span className="gradient-text">System</span></h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Celebrate excellence and motivate continuous innovation with our comprehensive recognition system that rewards outstanding contributions.
          </p>
        </div>
        
        <Tabs defaultValue="leaderboard" className="mb-16">
          <div className="flex justify-center mb-8">
            <TabsList>
              <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
              <TabsTrigger value="departments">Departments</TabsTrigger>
              <TabsTrigger value="badges">Achievement Badges</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="leaderboard">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {topInnovators.map((innovator, index) => (
                <Card key={index} className={`border-none shadow-md overflow-hidden ${
                  index === 0 ? 'ring-2 ring-yellow-400' : ''
                }`}>
                  <div className={`h-2 ${
                    index === 0 ? 'bg-yellow-400' : 
                    index === 1 ? 'bg-gray-400' : 
                    index === 2 ? 'bg-amber-600' : 'bg-blue-400'
                  }`}></div>
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center text-center">
                      <Avatar className="h-20 w-20 mb-4">
                        <AvatarImage src={innovator.image || undefined} />
                        <AvatarFallback className="bg-innovation-blue/10 text-innovation-blue">
                          {innovator.initials}
                        </AvatarFallback>
                      </Avatar>
                      
                      <h4 className="text-xl font-semibold mb-1">{innovator.name}</h4>
                      <p className="text-gray-500 mb-3">{innovator.department}</p>
                      
                      <div className="mb-4">
                        <span className="text-2xl font-bold text-innovation-purple">{innovator.score}</span>
                        <span className="text-gray-500 text-sm ml-1">innovation score</span>
                      </div>
                      
                      <div className="flex flex-wrap justify-center gap-2">
                        {innovator.achievements.map((achievement, i) => (
                          <Badge key={i} variant="outline" className="bg-gray-50">
                            {achievement}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="departments">
            <div className="max-w-3xl mx-auto">
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    {departmentRanking.map((dept, index) => (
                      <div key={index} className="flex items-center p-4 rounded-lg bg-gray-50">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white shadow-sm mr-4 text-gray-700 font-semibold">
                          {index + 1}
                        </div>
                        
                        <div className="flex-grow">
                          <h4 className="font-medium">{dept.name} Department</h4>
                          <div className="w-full bg-gray-200 h-2 rounded-full mt-2">
                            <div 
                              className="h-full rounded-full bg-gradient-to-r from-innovation-blue to-innovation-purple" 
                              style={{ width: `${(dept.score / 350) * 100}%` }}
                            ></div>
                          </div>
                        </div>
                        
                        <div className="ml-4 text-right">
                          <div className="font-semibold">{dept.score}</div>
                          <div className="text-sm text-green-600">{dept.change}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="badges">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {badges.map((badge, index) => (
                <Card key={index} className="card-hover">
                  <CardContent className="pt-6">
                    <div className="flex items-start">
                      <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mr-4">
                        {badge.icon}
                      </div>
                      <div>
                        <h4 className="font-semibold mb-1">{badge.name}</h4>
                        <p className="text-gray-600 text-sm">{badge.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
};

export default RecognitionSection;
